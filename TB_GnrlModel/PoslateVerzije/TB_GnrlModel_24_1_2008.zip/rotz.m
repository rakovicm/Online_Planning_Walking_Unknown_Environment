function T = RotZ(a)

T = [cos(a) -sin(a) 0;sin(a) cos(a) 0; 0 0 1];
