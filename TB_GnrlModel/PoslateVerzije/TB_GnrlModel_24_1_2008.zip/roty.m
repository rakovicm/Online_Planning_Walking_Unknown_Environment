function T = RotY(a)

T = [cos(a) 0 sin(a); 0 1 0; -sin(a) 0 cos(a)];
