function s = vmod(a)
%
% scalar = vmod( [3x3]_vector )
% returns the module of a spatial vector
%
s = sqrt(a'*a);
